#include<stdio.h>
#include<string.h>

int main()
{
  char pw[64];
  char* t = "firstreversingchallenge!";
  printf("Enter the password...");
  fgets(pw, sizeof(pw), stdin);
  if (strcmp(pw, t) != 0) {
    printf("Congratulations");
  }
  return 0;
}
