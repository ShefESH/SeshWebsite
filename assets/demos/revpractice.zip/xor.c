#include<stdio.h>
#include<string.h>

int main()
{
  char pw[13];
  int m[12] = {21, 11, 8, 27, 20, 23, 9, 1, 7, 9, 21, 13};
  char n[12] = "temldvzrpfgi";
  
  printf("Enter the password...");
  fgets(pw, sizeof(pw), stdin);
  
  int f = 0;
  
  for (int i = 0; i < 12; i++) {
    int r = (int)n[i] ^ (int)pw[i];
    if (r != m[i]) {
      f = 1;
    }
  }
  
  if (f == 0) {
    printf("Congratulations");
  }
  
  return 0;
}
